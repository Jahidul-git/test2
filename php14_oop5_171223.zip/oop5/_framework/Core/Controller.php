<?php
namespace Core;

class Controller
{
    public function __construct()
    {
        // class constructor
    }

    public function index()
    {
        echo 'This is our index method';
    }

    protected function view($view, $data)
    {
        \extract($data);

        include 'Views/' . rtrim($view, '.php') . '.php';
    }
}