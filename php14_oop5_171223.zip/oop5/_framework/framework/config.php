<?php

define('Root', __DIR__);