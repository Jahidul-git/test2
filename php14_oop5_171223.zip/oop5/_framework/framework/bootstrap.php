<?php
ini_set('display_errors', 'on');

// Include Config
require_once 'config.php';

// Class Autoload
spl_autoload_register(function($class){
    $class = ucfirst(str_replace('\\', '/', $class) . '.php');

    include $class;
});