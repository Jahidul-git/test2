<?php
use \Core\Controller as BaseController;

class Homepage extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'This is Title',
            'message' => 'This is a message'
        ];

        $this->view('homepage', $data);
    }

    public function about()
    {
        include 'Views/about.php';
    }
}