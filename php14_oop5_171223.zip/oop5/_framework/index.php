<?php
require_once 'framework/bootstrap.php';

if(isset($_GET['c'])) {
    $controller = $_GET['c'];
    $action = isset($_GET['m']) ? $_GET['m'] : 'index';

    $obj = new $controller;

    $obj->{$action}();
}