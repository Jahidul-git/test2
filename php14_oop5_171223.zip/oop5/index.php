<?php
ini_set('display_errors', 'on');

if(isset($_GET['route'])) {
    echo 'Our route: ' . $_GET['route'];
} else {
    echo 'No routes found';
}