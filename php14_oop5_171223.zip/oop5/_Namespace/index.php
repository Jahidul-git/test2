<?php
ini_set('display_errors', 'on');
/**
 * Namespace
 */

// spl_autoload_register(function($class){
//     $class = str_replace('\\', '/', $class);
//     include $class.'.php';
// });

// $obj = new Classes\ClassA;

// $obj->sayHello();
