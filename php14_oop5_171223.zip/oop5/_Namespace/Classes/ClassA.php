<?php
namespace Classes;

class ClassA {
    public function sayHello()
    {
        echo 'Hello';
    }
}