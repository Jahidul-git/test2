<?php
ini_set('display_errors', 'on');

spl_autoload_register(function($class){
    echo $class;
    include 'classes/' . $class .'.php';
});

define('ROOT', __DIR__);


/**
 * Sub Query
 * 
 // Without alias
 SELECT students.student_id, students.name, result.total_marks
 FROM students, result
 WHERE students.student_id = result.student_id AND result.total_marks
 IN (SELECT total_marks
     FROM result
     WHERE total_marks >= 80 AND total_marks <= 90)
 ORDER BY result.total_marks;

 
 // With alias
 SELECT s.student_id, s.name, r.total_marks
 FROM students s, result r
 WHERE s.student_id = r.student_id AND r.total_marks
 IN (SELECT total_marks
     FROM result
     WHERE total_marks >= 80 AND total_marks <= 90)
 ORDER BY r.total_marks;

*/