<?php
class TestA
{
    protected static $day = 'Tuesday';

    // instance\
    protected static $_instance = null;

    public function __construct()
    {
        // construct
    }

    public static function getInstance()
    {
        $self = __CLASS__;
        if(is_null($self::$_instance)) {
            $self::$_instance = new $self;
        }
        return $self::$_instance;
    }

    public function sayHello($name)
    {
        return "Hello {$name}!";
    }

    public static function setDay($d)
    {
        self::$day = $d;
    }

    public static function getDay()
    {
        return self::$day;
    }
}