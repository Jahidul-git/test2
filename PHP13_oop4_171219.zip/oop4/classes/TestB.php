<?php
final class TestB
{
    public function __construct()
    {
        // construct
    }

    public function greet($name, $time = 'day')
    {
        return "Good $time $name!";
    }
}