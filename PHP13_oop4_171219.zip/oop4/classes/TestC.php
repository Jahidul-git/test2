<?php

class TestC extends TestA
{
    // public function greet($name = '', $time = 'day')
    // {
    //     return "Hello $name, Good $time!";
    // }
}