<?php

/**
 * Static,
 * Final,
 * Namespace,
 * htaccess / sub-query
 */

include 'bootstrap.php';

// $ta = new TestA;
// $tb = new TestB;

// echo $ta->sayHello('John Doe') . '<br>';
// echo $tb->greet('Rynn Mear', 'morning');

// $ta = TestA::getInstance();
// $tb = TestA::getInstance();

// echo $ta->sayHello('John');


$tc = new TestB;

echo $tc->greet('John') .'<br>';
echo "Today is " . TestA::getDay() . '<br>';